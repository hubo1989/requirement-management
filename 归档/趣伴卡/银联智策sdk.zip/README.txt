1.目录说明
│  README.txt							//help
│  接入参数.txt							//账户参数(注意保密)
│  智策云API产品文档.pdf				//接入流程描述及注意事项
│  智策云接入流程文档.pdf
│  
└─程序包
    ├─sdk
    │      upa-advisors-client.jar		//SDK jar包
    │      
    ├─客户端测试工具
    │      application.yml				//测试工具系统参数配置文件
    │      case.json					//case配置文件,客户可自行配置
    │      clientTool.jar				//工具主体文件
    │      run.bat						//Windows 系统启动脚本
    │      run.sh						//Linux 系统启动脚本
    │      
    └─源码
            AD_repoweb_client.zip		//源码包, 内含SDK/ClientDemo源码, 客户对接可参考Demo模块SdkDemo.java程序